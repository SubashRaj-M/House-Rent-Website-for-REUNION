import React, { Component } from 'react';

class Community extends Component {
    render() {
        return (
            <div className="community">
                <h3>Community</h3>
                <div className="comment">
                John: Wheres my money
                </div>
                <div className="comment">
                    Wade: Sup
                </div>
            </div>
        );
    }
}

export default Community;