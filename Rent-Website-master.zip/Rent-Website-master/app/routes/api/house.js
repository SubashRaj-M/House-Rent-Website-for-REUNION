export default {
    create: function() {
        // STUB
    },
    getAll: function() {
        // STUB
    },
    get: function(req, res) {
        // STUB
    }
};
